import csv
import random
import numpy as np
import pandas as pd


sum = 0
for k in range(1000):
    x = random.randint()
    sum += x
    result = sum / k
    with open('test.csv', 'w') as f:
        f.writelines()
